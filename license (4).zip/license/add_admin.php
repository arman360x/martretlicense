<?php

session_start();


// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit;
}
// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if form data is posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate and sanitize input
    if (!empty($name) && !empty($email) && !empty($password)) {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Prepare the SQL statement
        $sql = "INSERT INTO admins (name, email, password) VALUES (:name, :email, :password)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters and execute the statement
        try {
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':password' => $hashedPassword
            ]);
            echo "Admin added successfully.";
        } catch (PDOException $e) {
            die("Error adding admin: " . $e->getMessage());
        }
    } else {
        echo "Please fill all fields.";
    }
} else {
    echo "Invalid request.";
}
?>
