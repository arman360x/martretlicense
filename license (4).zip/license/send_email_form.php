<?php
session_start();

// Include the Composer autoload file
require 'vendor/autoload.php';

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance for database connection
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch user details
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_sql = "SELECT email, name, license_key, expire_date FROM licenses WHERE id = :id";
$user_stmt = $pdo->prepare($user_sql);
$user_stmt->bindValue(':id', $user_id, PDO::PARAM_INT);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

// Prepare default values
$default_subject = 'Your LEILA download link is ready';
$default_message = sprintf(
    "Download LEILA here: https://drive.google.com/file/d/1R0Q96eOVcj-tJAHlfqm6N-zrdKDyGP68/view?usp=sharing;      License key: %s;      Expiry Date: %s;       YouTube channel for installation and usage: http://www.youtube.com/@LEILA-Trades",
    htmlspecialchars($user['license_key']),
    htmlspecialchars($user['expire_date'])
);


// Sender email
$sender_email = 'admin@leilatrades.com';
$receiver_email = $user['email'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = $receiver_email;
    $subject = htmlspecialchars($_POST['subject']) ?: $default_subject;
    $message = htmlspecialchars($_POST['message']) ?: $default_message;

    // Create a new PHPMailer instance
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'leilatrades.com'; // GoDaddy SMTP server
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'admin@leilatrades.com';                 // SMTP username
        $mail->Password   = 'Fiverr@2024';                         // SMTP password
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption
        $mail->Port       = 465;                                    // TCP port to connect to GoDaddy SMTP

        // Recipients
        $mail->setFrom($sender_email, 'Leila EA');
        $mail->addAddress($receiver_email);                         // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $message;

        // Send the email
        $mail->send();
        echo "<p>Email sent successfully!</p>";

        // Store email details in the database
        $insert_email_sql = "INSERT INTO emails (sender, receiver, subject, message, sent_at) VALUES (:sender, :receiver, :subject, :message, NOW())";
        $insert_email_stmt = $pdo->prepare($insert_email_sql);
        $insert_email_stmt->bindValue(':sender', $sender_email);
        $insert_email_stmt->bindValue(':receiver', $receiver_email);
        $insert_email_stmt->bindValue(':subject', $subject);
        $insert_email_stmt->bindValue(':message', $message);
        $insert_email_stmt->execute();
    } catch (Exception $e) {
        echo "Mailer Error: {$mail->ErrorInfo}";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Email</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
        }
        input, textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        textarea {
            resize: vertical;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Send Email to <?php echo htmlspecialchars($user['name']); ?></h1>
        <form action="" method="post">
            <label for="sender">Sender</label>
            <input type="text" id="sender" name="sender" value="<?php echo htmlspecialchars($sender_email); ?>" readonly>

            <label for="receiver">Receiver</label>
            <input type="text" id="receiver" name="receiver" value="<?php echo htmlspecialchars($receiver_email); ?>" readonly>

            <label for="subject">Subject</label>
            <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($default_subject); ?>" required>

            <label for="message">Message</label>
            <textarea id="message" name="message" rows="10" required><?php echo htmlspecialchars($default_message); ?></textarea>

            <div class="button-group">
                <button type="submit">Send Email</button>
                <!-- Dashboard redirect button -->
                <button type="button" onclick="window.location.href='dashboard.php'">Go to Dashboard</button>
            </div>
        </form>
    </div>
</body>
</html>
