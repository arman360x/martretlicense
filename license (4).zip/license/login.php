<?php
session_start();

// Check if the user is trying to access a page that requires authentication (like dashboard.php)
if (basename($_SERVER['PHP_SELF']) != 'login.php' && !isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit;
}

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if form data is posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input
    if (!empty($email) && !empty($password)) {
        // Prepare the SQL statement
        $sql = "SELECT * FROM admins WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if admin exists and verify password
        if ($admin && password_verify($password, $admin['password'])) {
            // Set session variables and redirect to dashboard
            $_SESSION['user'] = [
                'id' => $admin['id'],
                'name' => $admin['name']
            ];
            header("Location: dashboard.php");
            exit;
        } else {
            // Invalid email or password
            $_SESSION['error'] = "Invalid email or password.";
            header("Location: login.php");
            exit;
        }
    } else {
        // Input validation failure
        $_SESSION['error'] = "Please fill all fields.";
        header("Location: login.php");
        exit;
    }
} else {
    $_SESSION['error'] = "Invalid request method.";
    header("Location: login.php");
    exit;
}
