<?php
session_start();

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid request.");
}

$id = (int)$_GET['id'];

// Fetch the user record to edit
$sql = "SELECT * FROM licenses WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$record = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$record) {
    die("User not found.");
}

// Handle form submission for editing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $account_number = trim($_POST['account_number']);
    $broker_name = trim($_POST['broker_name']);
    $license_key = trim($_POST['license_key']);
    $promo_code = trim($_POST['promo_code']);
    $expire_date = $_POST['expire_date'];
    $phone = trim($_POST['phone']);
    $description = trim($_POST['description']);

    // Validate and sanitize input
    if (!empty($name) && !empty($email) && !empty($account_number) && !empty($broker_name) && !empty($license_key) && !empty($expire_date)) {
        // Prepare the SQL statement for updating
        $sql = "UPDATE licenses SET name = :name, email = :email, account_number = :account_number, broker_name = :broker_name, 
                license_key = :license_key, promo_code = :promo_code, expire_date = :expire_date, phone = :phone, 
                description = :description WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        // Bind parameters and execute the statement
        try {
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':account_number' => $account_number,
                ':broker_name' => $broker_name,
                ':license_key' => $license_key,
                ':promo_code' => $promo_code,
                ':expire_date' => $expire_date,
                ':phone' => $phone,
                ':description' => $description,
                ':id' => $id
            ]);
            header("Location: success.html");
            exit();
        } catch (PDOException $e) {
            die("Error updating user: " . $e->getMessage());
        }
    } else {
        echo "Please fill all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 5% auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            border: 1px solid #ced4da;
        }
        .container h1 {
            text-align: center;
            color: #495057;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #343a40;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ced4da;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.075);
        }
        .form-control:focus {
            border-color: #80bdff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            color: #ffffff;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid transparent;
            cursor: pointer;
            transition: background-color 0.3s, border-color 0.3s;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .btn-primary:focus {
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit User</h1>
        <form action="edit_user.php?id=<?php echo htmlspecialchars($id); ?>" method="post">
            <div class="form-group">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($record['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($record['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="account_number" class="form-label">Account Number</label>
                <input type="text" class="form-control" id="account_number" name="account_number" value="<?php echo htmlspecialchars($record['account_number']); ?>" required>
            </div>
            <div class="form-group">
                <label for="broker_name" class="form-label">Broker Name</label>
                <input type="text" class="form-control" id="broker_name" name="broker_name" value="<?php echo htmlspecialchars($record['broker_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="license_key" class="form-label">License Key</label>
                <input type="text" class="form-control" id="license_key" name="license_key" value="<?php echo htmlspecialchars($record['license_key']); ?>" required>
            </div>
            <div class="form-group">
                <label for="promo_code" class="form-label">Promo Code</label>
                <input type="text" class="form-control" id="promo_code" name="promo_code" value="<?php echo htmlspecialchars($record['promo_code']); ?>">
            </div>
            <div class="form-group">
                <label for="expire_date" class="form-label">Expire Date</label>
                <input type="date" class="form-control" id="expire_date" name="expire_date" value="<?php echo htmlspecialchars($record['expire_date']); ?>" required>
            </div>
            <div class="form-group">
                <label for="phone" class="form-label">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($record['phone']); ?>">
            </div>
            <div class="form-group">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="4"><?php echo htmlspecialchars($record['description']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update User</button>
        </form>
    </div>
</body>
</html>
