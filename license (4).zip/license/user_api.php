<?php
header("Content-Type: application/json");

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
    exit();
}

// Check if the license_key is provided
$license_key = isset($_GET['license_key']) ? $_GET['license_key'] : '';

if (empty($license_key)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid or missing license key."]);
    exit();
}

// Prepare the SQL statement to fetch user data based on license_key
$user_sql = "SELECT id, name, email, account_number, broker_name, license_key, expire_date, is_enabled FROM licenses WHERE license_key = :license_key";
$user_stmt = $pdo->prepare($user_sql);
$user_stmt->bindValue(':license_key', $license_key, PDO::PARAM_STR);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    http_response_code(404);
    echo json_encode(["error" => "User not found."]);
    exit();
}

// Return user data as JSON
echo json_encode($user);
?>
