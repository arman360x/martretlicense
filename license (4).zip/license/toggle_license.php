<?php
// Include database connection
$config = require 'config.php';
$pdo = new PDO(
    "mysql:host={$config['host']};dbname={$config['dbname']}",
    $config['user'],
    $config['pass']
);

// Get the license ID from the query parameters
$id = (int)$_GET['id'];

// Fetch the current status
$sql = "SELECT is_enabled FROM licenses WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$license = $stmt->fetch(PDO::FETCH_ASSOC);

if ($license) {
    // Toggle the status
    $new_status = $license['is_enabled'] ? 0 : 1;
    $update_sql = "UPDATE licenses SET is_enabled = :new_status WHERE id = :id";
    $update_stmt = $pdo->prepare($update_sql);
    $update_stmt->bindValue(':new_status', $new_status, PDO::PARAM_INT);
    $update_stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $update_stmt->execute();
}

// Redirect back to the dashboard
header("Location: dashboard.php");
exit;
?>
